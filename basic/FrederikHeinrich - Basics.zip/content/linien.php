<linien>
    <hr class="full"><br>
    <hr class="small"><br>
    <hr class="middle"><br>
    <hr class="full height2"><br>
    <hr class="full height20"><br>
    <hr class="middle center"><br>
    <hr class="middle left"><br>
    <hr class="middle right"><br>
</linien>