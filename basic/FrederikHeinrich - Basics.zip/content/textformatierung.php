<p>Nach dem<br>Befehl<br>fängt eine neue<br>Zeile an,<br>wenn man die Seite<br>im Browser<br>anschaut.</p>
<br>
<p class="left">Der Text innerhalb dieses Befehls ist linksbündig. Das bedeutet, dass alle Zeilen auf der linken Seite anfangen</p>
<p class="center">Der Text innerhalb dieses Befehls steht auf der Mittelachse. Das bedeutet, dass alle Zeilen in der Mitte stehen.</p>
<p class="right">Der Text innerhalb dieses Befehls ist rechtsbündig. Das bedeutet, dass die Zeilen alle auf der rechten Seite an einer geraden Kante aufhören.</p>