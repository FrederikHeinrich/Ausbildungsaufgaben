<colspanundrowspan class="content">
<table>
  <tr>
    <td rowspan="6">Diese Spalte geht über sechs Reihen</td>
    <td colspan="4">Diese Spalte geht über vier Spalten</td>
    <td rowspan="6">Diese Spalte geht über sechs Reihen</td>
  </tr>
  <tr>
    <td rowspan="2">Diese Spalte geht über zwei Reihen</td>
    <td colspan="2">Diese Spalte geht über die Breite von zwei Spalten</td>
    <td rowspan="2">Diese Spalte geht über zwei Reihen</td>
  </tr>
  <tr>
    <td>Eine Spalte</td>
    <td>Eine Spalte</td>
  </tr>
  <tr>
    <td rowspan="2">Diese Spalte geht über zwei Reihen</td>
    <td>Eine Spalte</td>
    <td>Eine Spalte</td>
    <td rowspan="2">Diese Spalte geht über zwei Reihen</td>
  </tr>
  <tr>
    <td colspan="2">Diese Spalte geht über die Breite von zwei Spalten</td>
  </tr>
  <tr>
    <td colspan="4">Diese Spalte geht über vier Spalten</td>
  </tr>
</table>
</colspanundrowspan>