<h1>Startseite</h1>
<p>Dies ist die Startseite!</p>
<p>Hier ist Platz für Texte oder Bilder...</p>