<farben>
    <style>
        content {
            background-color: black;
        }
        a:visited{
            color: red;
        }
        a:link{
            color: blue;
        }
    </style>
    <p class="white">Der Hintergrund dieser Seite ist schwarz.</p>
    <p class="white">Der Text ist weiß.</p>
    <p class="green">Der Text ist grün.</p>
    <p class="red">Die besuchten Links sind rot.</p>
    <p class="blue">Die unbesuchten Links sind blau.</p>
    <p class="black">Der Text ist schwarz.</p>
</farben>