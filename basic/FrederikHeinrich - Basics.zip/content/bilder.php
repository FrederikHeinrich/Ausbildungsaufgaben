<bilder class="content">
    <bild class="ersteente"><p><img src="content/ente.jpg"/>Ein kleines gelbes Quietscheentchen</p></bild>
    <bild class="zweiteente"><p><img src="content/ente.jpg"/>Ein kleines gelbes Quietscheentchen</p></bild>
    <bild class="dritteente"><p>Ein kleines gelbes Quietscheentchen <img src="content/ente.jpg"/></p></bild>
</bilder>

<!-- Bewerbung geht vor -->