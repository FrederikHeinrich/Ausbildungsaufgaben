<listen>
    <ul class="normal">
        <li>Birabelle</li>
        <li>Ananas</li>
        <li>Pampelmuse</li>
        <li>Kiwi</li>
    </ul>
    <ul class="bloxs">
        <li>Birabelle</li>
        <li>Ananas</li>
        <li>Pampelmuse</li>
        <li>Kiwi</li>
    </ul>
    <ul class="emptydots">
        <li>Birabelle</li>
        <li>Ananas</li>
        <li>Pampelmuse</li>
        <li>Kiwi</li>
    </ul>
    <ul class="numbers">
        <li>Birabelle</li>
        <li>Ananas</li>
        <li>Pampelmuse</li>
        <li>Kiwi</li>
    </ul>
</listen>