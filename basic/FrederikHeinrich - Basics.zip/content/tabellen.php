<tabellen>
    <style>
        content{
        background-color: green;
        }
    </style>

    <table>
        <tr>
            <td>Das ist die erste Spalte in der ersten Reihe.</td>
            <td>Das ist die zweite Spalte in der ersten Reihe.</td>
            <td>Das ist die dritte Spalte in der ersten Reihe.</td>
        </tr>
        <tr>
            <td>Das ist die erste Spalte in der zweiten Reihe.</td>
            <td>Das ist die zweite Spalte in der zweiten Reihe.</td>
            <td>Das ist die dritte Spalte in der zweiten Reihe.</td>
        </tr>
    </table>
</tabellen>
