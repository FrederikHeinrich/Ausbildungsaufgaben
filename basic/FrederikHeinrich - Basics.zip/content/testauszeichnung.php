<textausrichtung>
    <p><i>Das ist ein kursiv geschriebener Text.</i></p>
    <p><b>Dieser Text ist fett.</b></p>
    <p><u>Unterstrichener Text</u></p>
    <p>Dies hier ist <sup>hochgestelter</sup> Text</p>
    <p>Dies hier ist <sub>tiefgestellter</sub> Text</p>
</textausrichtung>